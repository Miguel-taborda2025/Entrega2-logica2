class Nodo {
    int dato;
    Nodo siguiente;

    public Nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}
class ListaSimples {
    private Nodo cabeza;

    //este es el método para agregar un nodo al final
    public void agregar(int dato) {
        Nodo nuevo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }

    // este es un método para eliminar un nodo por su valor
    public void eliminar(int dato) {
        if (cabeza == null) return;

        if (cabeza.dato == dato) {
            cabeza = cabeza.siguiente;
            return;
        }

        Nodo actual = cabeza;
        while (actual.siguiente != null && actual.siguiente.dato != dato) {
            actual = actual.siguiente;
        }

        if (actual.siguiente != null) {
            actual.siguiente = actual.siguiente.siguiente;
        }
    }

    // este método se encarga de  imprimir la lista
    public void imprimir() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.print(actual.dato + " -> ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }
}
// esta es la clase principal para ejecutar el código
public class main {
    public static void main(String[] args) {
        ListaSimples lista = new ListaSimples();
        
        lista.agregar(1);
        lista.agregar(2);
        lista.agregar(3);
        lista.imprimir(); // ejemplo de la salida: 1 -> 2 -> 3 -> null

        lista.eliminar(2);
        lista.imprimir(); // ejemplo de la salida en este caso: 1 -> 3 -> null
    }
}
