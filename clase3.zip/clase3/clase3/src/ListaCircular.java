public class ListaCircular {
    private Nodo cabeza = null;
    private Nodo cola = null;

     //los parentesis llevan o llaman atributos en los métodos, 
     //y cuando un tributo tienen un valor se convierte en un parametro
     //las llaves contienen la información del método
    public void insertar(int x, int y) {
        Nodo nuevo = new Nodo(x, y);
        if (cabeza == null) {
            cabeza = nuevo;
            cola = nuevo;
            cabeza.siguiente = cabeza;            
        } else {
            cola.siguiente = nuevo;
            nuevo.siguiente = cabeza;
            cola = nuevo;
        }
        
    }
    public Nodo getCabeza(){
        return cabeza;

    }

}
